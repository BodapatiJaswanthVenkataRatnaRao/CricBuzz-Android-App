package com.example.cricbuzz_swaroop

data class MoreItem(val iconResId: Int, val title: String)
