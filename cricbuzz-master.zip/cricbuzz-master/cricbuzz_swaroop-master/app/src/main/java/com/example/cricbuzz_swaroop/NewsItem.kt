package com.example.cricbuzz_swaroop

data class NewsItem(val imageResId: Int, val title: String, val description: String)
